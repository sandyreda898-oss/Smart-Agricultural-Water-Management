This readme file was generated on [2025-10-27] by [Olfa Gharsallah]


# GENERAL INFORMATION

* CS1-Agricultural season 2020: 
*provide at least two contacts*
## Author/Principal Investigator Information
Name: Abdrabbo A. A. S. Aboukheira
ORCID:-
Institution: National Water Research Center, Delta Barrage, Kalyubiya, Egypt 
Address: Shubra El Kheima 1, Al-Qalyubia Governorate 6210001, Egitto
Email: abdo23870@gmail.com


## Author/Associate or Co-investigator Information
Name: Saad M. Metwaly Shebl
ORCID:-
Institution: Agricultural Research Center, Dokki, Giza, Egypt
Address: 9 Cairo University Rd, Oula, Al Giza, Giza Governorate 3725004, Egitto
Email: saad.shebl@yahoo.com 


 
* Date of data collection: from 2020-06-06 till 2020-10-31. 
* Geographic location of data collection: Sakha Experiment Station (North Nile Dela) and Kafr El-Hamam Experiment Station (East Nile Delta), Egypt.  
* Information about funding sources that supported the collection of the data: MEDWATERICE-funded by PRIMA section 2, 2018


# SHARING/ACCESS INFORMATION

* Licenses/restrictions placed on the data: CC0 license
* Links to publications that cite or use the data: https://www.medwaterice.org/downloads/
* Links to other publicly accessible locations of the data: -
* Links/relationships to ancillary data sets: -
* Was data derived from another source?
	* If yes, list source(s): 
* Recommended citation for this dataset: Aboukheira, A.A.A.S and ShebL, S.M.M (2020). MEDWATERICE— Nile Delta (Egypt)case study dataset, Agricultural season 2020. Dataset. University of Milan Dataverse



# DATA & FILE OVERVIEW

## File List: This dataset contains data collected during the 2020 agricultural season in the Nile Delta case study (Egypt). Four irrigation strategies were tested: in the Northern Nile Delta, traditional flooding (WFL) and HYBRID, each tested with two water qualities (freshwater and drainage water) (MEDWATERICE DMP_CS6_EGYPT_WFL-FRESHWATER_2020.xlsx; MEDWATERICE DMP_CS6_EGYPT_WFL-DRAINAGE WATER_2020.xlsx; MEDWATERICE DMP_CS6_EGYPT_HYBRID-FRESHWATER_2020.xlsx; and MEDWATERICE DMP_CS6_EGYPT_HYBRID-DRAINAGE WATER_2020.xlsx); and in the Eastern Nile Delta, sprinkler irrigation (MEDWATERICE DMP_CS6_EGYPT_SPRINKLER_2020.xlsx) and surface drip irrigation (MEDWATERICE DMP_CS6_EGYPT_DRIP_2020.xlsx). For each strategy, three cultivation methods were applied (drill seeding, raised beds, and the System of Rice Intensification (SRI)) in combination with five rice varieties (Giza 177, Giza 178, Sakha Super 300, Hybrid Rice-EH1, and Dry Rice-L1). The dataset also includes the experimental field layouts (MEDWATERICE_EXPERIMENTAL LAYOUT_CS6_EGYPT_2020.pdf) and detailed information on the cultivated rice varieties (MEDWATERICE DMP_CS6_EGYPT_varieties_2020.pdf).


* Relationship between files, if important: No
* Additional related data collected that was not included in the current data package: No
* Are there multiple versions of the dataset?                                          No
	* If yes, name of file(s) that was updated: 
	* Why was the file updated? 
	* When was the file updated? 


# METHODOLOGICAL INFORMATION

## Description of methods used for collection/generation of data:  

In the experimental platform conducted during the 2020 agricultural season, the following data were monitored and included in Excel files: Agro-climatic data, Soil physico-chemical properties, Irrigation volumes and quality, Water balance components, Rice yield, Soil, crop and irrigation management operations.
Each Excel file contains 13 sheets. The first sheet, titled "General", provides details such as: type of data, variable, units, whether the variable is measured (M) or estimated (E), the time step of measurement/estimation (e.g., every 10 minutes, hourly, daily, seasonal, etc.), the number of measurement/estimation points for the experimental farm, the measuring device or estimation method, and the data format (Excel).



# DATA-SPECIFIC INFORMATION FOR and Methods for porcessing data: [All datasets]

Data collected in each pilot farm in the agricultural seasons were organized in Excel format files. Image files (JPG, GIF, SVG, PNG, TIFF) illustrating the layout of the experimental activities in each pilot farm, and additional PDF files presenting the rice varieties cropped during the three experimental seasons were moreover prepared. Data series refer to a period of about 150 days (i.e. average length of the rice crop cycle in the Mediterranean basin). Average data volume produced for each experimental year for each CS is about 5 MB.
In the MEDWATERICE project, NO sensible data have been collected during the research. Data collected are compliant with GDPR. NO human biological samples have been collected in the research. NO children have been involved in the research.

Each Excel file contains 13 sheets. The first sheet, titled "General", provides details such as: type of data, variable, units, whether the variable is measured (M) or estimated (E), the time step of measurement/estimation (e.g., every 10 minutes, hourly, daily, seasonal, etc.), the number of measurement/estimation points for the experimental farm, the measuring device or estimation method, and the data format (Excel)."